When Is Video Enough? Predicting Deformable Object Responses to New Interactions
Anonymous review manuscript, 9 November 2026

Read main.pdf and supplement.pdf together. The source is in main.tex,
supplement.tex and sections/. The standalone release is release/latex-source.zip.

What is evaluated
-----------------
The joint-field experiment infers spatial material, support and load fields from
known-geometry projected displacements. It integrates unknown Gaussian temporal
load amplitudes analytically when the mechanical observation map is affine in load.
The separate dynamic trials infer material hypotheses under known commands. The
completed prospective diagonal push uses RGB-D surface tracks for ours and ten
RGB fitting views for GIC. The 96-case beam study evaluates the decision to
proceed, look or push under known costs and a separate tolerance.

The new RGB-only protocol pairs GIC, PAC-NeRF and our model across a 20 N stem
push (D2c), a held off-centre block press, and a free-striker impact. S1 and S3
share the stem geometry and calibration episodes. No new comparison scores were
published at the evidence revision below. The earlier lateral push D2, diagonal
push D2b, torus continuation, and contact comparisons have distinct evaluation
conditions. None supplies a missing cell in that matrix.

Evidence and source map (paths relative to the repository root)
--------------------------------------------------------------
docs/JOINT_FIELD_IDENTIFICATION.md                 inference, assumptions and implementation
reports/joint-field-surface-v04/                  matched, continuous and mismatch cohorts
reports/joint-field-hierarchy-surface-v05/        independent uncertain-force-scale study
reports/joint-field-temporal-v06/                 temporal-prior follow-up
reports/joint-field-fine-v03/                     interior-sensor resolution control
reports/gap-first-v01/                            native drop, 96-case stem and bowl contact
reports/gap-crossmethod-v02/                      paired GIC/PAC-NeRF torus and audit
reports/stem-trial-v01/                           20 N/25 N stem scores and prediction seals
reports/complex-scenes-v18/                       matched-track, shared-renderer contact controls
scripts/fig1_v01/protocol_fig1.json               new unscored RGB-only benchmark specification
results-provenance.json                           SHA-256 hashes for the joint-field study
interaction-provenance.json                       SHA-256 hashes for dynamic results, figures and protocols

Completion status checked against c610ef6ee85c42c5a1f653f18d1588ac6ced123e.
The common-appearance scoring analysis for the 25 N diagonal push changed after
the recorded protocol; the motion predictions had already been sealed. The
supplement describes the amendment. Real PokeFlex recordings and trained-model
assets are outside this paper release.
To verify the archived inputs and regenerate the source bundle in a repository
checkout, run python scripts/joint_field_identification/package_paper.py at its root.

Build
-----
Run bash build.sh in this directory (or after extracting the source ZIP).
The script compiles both anonymous PDFs using Tectonic or latexmk. The repository
copy reads the recorded stem panels under output/; the source release includes
the same panels in figures/ for a standalone build. All figures needed for
typesetting are supplied as PDFs. To regenerate the teaser from the original
evidence in the repository, run python figures/make_task_teaser.py.

The main paper includes the LLM Usage Statement before the references. No
OpenReview submission identifier has been supplied. The author should review the
statement, author information and Figure 1 benchmark status before submission.

Earlier release
---------------
gap-first-addendum.pdf and release/gap-first-latex-source.zip are the 7 November
addendum. The earlier new-study-supplement.pdf and legacy-supporting-evidence.pdf
remain historical files. The current supplement is self-contained; rebuilding
it no longer appends the older platform paper.
