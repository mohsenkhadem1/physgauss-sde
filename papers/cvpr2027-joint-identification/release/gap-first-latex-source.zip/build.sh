#!/bin/sh
set -eu
cd "$(dirname "$0")"
tectonic -X compile main.tex
