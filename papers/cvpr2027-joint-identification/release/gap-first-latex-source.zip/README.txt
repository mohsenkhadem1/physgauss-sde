Gap-first experimental addendum: editable standalone LaTeX source.

Run: sh build.sh
Requires Tectonic and its standard LaTeX packages. All included figure PDFs
embed their fonts; the original simulation environments are not required to
build this document. Experimental reproduction instructions and raw-data
policies remain in the repository reports/gap-first-v01/ directory.

This supplements the existing joint-identification manuscript; it does not
replace or relabel earlier rendering, public-data, or contact results.
