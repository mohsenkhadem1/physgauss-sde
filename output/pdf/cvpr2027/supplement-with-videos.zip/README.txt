Supplementary media: Compositional Neural Mechanics for Physical Prediction Beyond Visual Agreement

Read supplement.pdf for equations, complete-case and failed-case accounting,
reference sensitivity, and the scope of each experiment.

media/world-{0,1,2,3}-forecast-{40,80}mm-held0.mp4:
All eight declared held-view forecasts, with synchronized reference, our model,
and native PhysTwin. World 3 has unavailable native predictions, visibly marked.
31 saved frames cover 0.30 simulated seconds. Playback is 10 fps (10x slow motion).
There is no deformation magnification. Reference means finite-resolution
simulation, not real captured footage or a continuum-converged ground truth.

Four development examples are also included:
position-compression-development.mp4: position-driven compression/hold/unload.
finite-striker-development.mp4: conservative finite-mass sphere impact demo.
drop-bounce-settle-development.mp4: separate viscous drop/bounce/settle demo.
development-orbit-actual-ours-native-v2.mp4: development comparison with orbiting camera.
These are development examples, not additional held-cohort test successes.
Striker and viscous demonstrations have the qualification limits in supplement.pdf.
No external links, raw datasets or identifying author information are required.
